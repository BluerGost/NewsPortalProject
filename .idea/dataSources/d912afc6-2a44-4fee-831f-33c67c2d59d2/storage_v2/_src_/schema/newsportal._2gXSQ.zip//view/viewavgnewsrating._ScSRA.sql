create view viewavgnewsrating as
  select
    `newsportal`.`tblrating`.`newsId`      AS `newsId`,
    avg(`newsportal`.`tblrating`.`rating`) AS `avg_rating`
  from `newsportal`.`tblrating`
  group by `newsportal`.`tblrating`.`newsId`;

